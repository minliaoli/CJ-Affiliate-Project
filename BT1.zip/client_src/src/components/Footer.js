import React, { Component } from 'react'

export class Footer extends Component {
    render() {
        return (
            <footer>
                <p>CJ Affiliate & The Great Fantastic Team, Copyright &copy; , 2019 </p>
            </footer>
        )
    }
}

export default Footer
