import React from 'react';
import '../css/App.css';

class About extends React.Component {


  render() {
    // console.log(this.state.todos)
    return (
      <div className="App">
        
        <section id = "App-selection">
          <div className="App-container">
            <h2>This is About!</h2>
          </div>
        </section>



      </div>
    );
  }
}


export default About;