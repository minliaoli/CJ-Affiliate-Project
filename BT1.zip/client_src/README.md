# CJ-Affiliate-Project
Team name: Great Fantastic Team

Team members:
  Joey ZHANG (Lead),
  Nathan Guan (Scribe),
  Minliao Li,
  Zhuo Chen,
  Kyle Ng


Trello: https://trello.com/b/rNy18nT7/lets-get-stuff-done

Project: Blogger Project

Project overview: A tool matching the best products/offers based on real-time soical media, local events, blog content and so on. 



How to Use:
1. $npm install

2. npm install axios --save

