'use strict';

module.exports = function(Tryout) {

};
