'use strict';

module.exports = function(Offers) {

};
